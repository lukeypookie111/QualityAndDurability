﻿using HarmonyLib;
using JetBrains.Annotations;
using System;
using System.Reflection.Emit;
using Verse.AI;
using RimWorld;
using RimWorld.Planet;
using Verse;
using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Amnabi{
	[StaticConstructorOnStartup]
    public static class Harmony_QualityAndDurability{
        static Harmony_QualityAndDurability(){
            HarmonyLib.Harmony harmony = new HarmonyLib.Harmony("Amnabi.QualityAndDurability");
            harmony.PatchAll();
			harmony.Patch(
                AccessTools.Method(typeof(CompQuality), "SetQuality"),
				null,
                new HarmonyMethod(typeof(Harmony_QualityAndDurability), nameof(SetQualityPatch)),
                null);
			harmony.Patch(
                AccessTools.DeclaredPropertyGetter(typeof(Thing), "MaxHitPoints"),
				null,
                new HarmonyMethod(typeof(Harmony_QualityAndDurability), nameof(MaxHitPointsPatch)),
                null);
        }
		public static void SetQualityPatch(QualityCategory q, ArtGenerationContext source, CompQuality __instance){
			__instance.parent.HitPoints = __instance.parent.MaxHitPoints;
		}
		public static void MaxHitPointsPatch(Thing __instance, ref int __result){
			if(__instance.def.IsWeapon || __instance.def.IsApparel){
				CompQuality qualityComp = __instance.TryGetComp<CompQuality>();
				if(qualityComp != null){
					__result = (int)(__result * adjustSwitch(qualityComp.Quality));
				}
			}
		}

		public static float adjustSwitch(QualityCategory q){
			switch(q){
				case QualityCategory.Awful:{
					return 0.5f;
				}
				case QualityCategory.Poor:{
					return 0.75f;
				}
				case QualityCategory.Normal:{
					return 1.0f;
				}
				case QualityCategory.Good:{
					return 1.25f;
				}
				case QualityCategory.Excellent:{
					return 1.5f;
				}
				case QualityCategory.Masterwork:{
					return 2.5f;
				}
				case QualityCategory.Legendary:{
					return 5f;
				}
			}
			return 1.0f;
		}

    }
}